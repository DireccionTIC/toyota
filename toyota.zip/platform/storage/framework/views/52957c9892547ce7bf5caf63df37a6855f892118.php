

<?php $__env->startSection('content'); ?>
    <h4>Cupones redimidos:</h4>

    <?php if(count($cuponsRedimidos) == 0): ?>
        <div class="ms-4">No hay cupones redimidos</div>
    <?php endif; ?>

    <?php $__currentLoopData = $cuponsRedimidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-light border mt-3" role="alert">
            <h4 class="alert-heading"><?php echo e($cupon->placa); ?></h4>
            <hr>
            <p class="mb-0"> <span class="fw-bold">Sitio:</span> <?php echo e($cupon->city); ?><br>
            <span class="fw-bold">Por:</span> <?php echo e($cupon->who); ?><br>
            <span class="fw-bold">Día y hora:</span> <?php echo e($cupon->updated_at); ?><br><br></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <h4 class="mt-3">Cupones redimibles:</h4>

    <?php if(count($cuponsRedimibles) == 0): ?>
        <div class="ms-4">No hay cupones redimibles</div>
    <?php endif; ?>
    <?php $__currentLoopData = $cuponsRedimibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-light border mt-3" role="alert">
            <h4 class="alert-heading"><?php echo e($cupon->placa); ?></h4>
            <hr>
            <p class="mb-0"> <span class="fw-bold">Descuento:</span> 20%<br>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if(Session::has('registed')): ?>
        <div class="alert alert-danger mt-2"><?php echo e(Session::get('registed')); ?></div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jmorales\Desktop\npm\mi-proyecto-laravel\resources\views/reportes-admin.blade.php ENDPATH**/ ?>