

<?php $__env->startSection('content'); ?>

    <h1>Pag de reportes</h1>
    <?php if(@Auth::user()->hasRole('admin')): ?>
        <h2>Eres un admin</h2>
    <?php endif; ?>
    Cupones redimidos: <br><br>

    <?php if(count($cuponsRedimidos) == 0): ?>
       No hay cupones redimidos<br><br>
    <?php endif; ?>
    <?php $__currentLoopData = $cuponsRedimidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
        Placa: <?php echo e($cupon->placa); ?><br>
        Sitio: <?php echo e($cupon->city); ?><br>
        Por: <?php echo e($cupon->who); ?><br>
        Día y hora: <?php echo e($cupon->updated_at); ?><br><br>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    Cupones redimibles: <br><br>

    <?php if(count($cuponsRedimibles) == 0): ?>
       No hay cupones redimibles<br><br>
    <?php endif; ?>
    <?php $__currentLoopData = $cuponsRedimibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
        Placa: <?php echo e($cupon->placa); ?><br>
        Sitio: <?php echo e($cupon->city); ?><br>
        Por: <?php echo e($cupon->who); ?><br>
        Día y hora: <?php echo e($cupon->updated_at); ?>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jmorales\Desktop\npm\mi-proyecto-laravel\resources\views/reportes.blade.php ENDPATH**/ ?>