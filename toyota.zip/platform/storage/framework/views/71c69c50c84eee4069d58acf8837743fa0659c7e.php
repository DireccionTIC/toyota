
<?php $__env->startSection('header'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/register.css')); ?>">
    <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
    <a href="/toyotaqr/public" target="__blank">
        <img src="<?php echo e(asset('img/logo-toyota.png')); ?>" alt="LOGO TOYOTA" class="Logo-Toyota">
    </a>
        <!-- Right Side Of Navbar -->
    <ul>
        <!-- Authentication Links -->
        <li >
            <a id="navbarDropdown" class="" href="<?php echo e(route('home')); ?>">
                Lector
            </a>
        </li>
        <?php if(@Auth::user()->hasRole('admin')): ?>
            <li >
                <a id="navbarDropdown"  href=" <?php echo e(route('reportes')); ?> ">
                    Reportes
                </a>
            </li>
            <li>
                <a id="navbarDropdown"  href=" <?php echo e(route('cupon.view.edit')); ?>">
                    Editar cupones
                </a>
            </li>
            <li>
                <a id="navbarDropdown" class="actived"  href=" <?php echo e(route('create.user')); ?>">
                    Crear usuario   
                </a>
            </li>
            <li>
                <a id="navbarDropdown"  href=" <?php echo e(route('reset.password')); ?>">
                    Resetear contraseña   
                </a>
            </li>
            <?php endif; ?>
            <?php if(@Auth::user()->hasRole('rol2')): ?>
            <li>
                <a id="navbarDropdown" href="<?php echo e(route('reportes')); ?>">
                    Reportes
                </a>
            </li>
            <?php endif; ?>
            <li>
                <a id="navbarDropdown"  href=" <?php echo e(route('change.password')); ?>">
                    Cambiar contraseña
                </a>
            </li>
  
        <li class="nav-item dropdown">
            <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
                Cerrar sesión
            </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
        </li>
    </ul>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register.admin')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <input id="name" type="text" placeholder="Ingrese el nombre" class="input-login form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                                <br>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">

                            <div class="col-md-6">
                                <input id="email" type="email" placeholder="Ingrese el correo" class="input-login form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                    <br>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <input id="password" type="password" placeholder="Ingrese la contraseña" class="input-login form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">
                                <br>

                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <input id="password-confirm" type="password" placeholder="Confirme la contraseña" class="input-login form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="row mb-0 mt-2">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="button-login">
                                    Registrar
                                </button>
                            </div>
                        </div>
                        <?php if(Session::has('registed')): ?>
                            <strong><?php echo e(Session::get('registed')); ?></strong>
                        <?php endif; ?>
                    </form>
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Juan\Downloads\toyota-app\resources\views/register-admin.blade.php ENDPATH**/ ?>