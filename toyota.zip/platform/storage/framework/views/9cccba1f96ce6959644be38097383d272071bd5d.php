<?php echo e($slot); ?>

<?php /**PATH C:\Users\jmorales\Desktop\TOYOTA-APP\toyota-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>