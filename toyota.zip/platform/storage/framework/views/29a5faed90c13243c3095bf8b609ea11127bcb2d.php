
<?php $__env->startSection('header'); ?><link rel="stylesheet" href="<?php echo e(asset('css/edit.css')); ?>">
<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
    <a href="/toyotaqr/public" target="__blank">
        <img src="<?php echo e(asset('img/logo-toyota.png')); ?>" alt="LOGO TOYOTA" class="Logo-Toyota">
    </a>
        <!-- Right Side Of Navbar -->
    <ul class="">
        <!-- Authentication Links -->
        <li class="">
            <a id="navbarDropdown" class="" href="<?php echo e(route('home')); ?>">
                Lector
            </a>
        </li>
        <?php if(@Auth::user()->hasRole('admin')): ?>
            <li class="">
                <a id="navbarDropdown" class="" href=" <?php echo e(route('reportes')); ?> ">
                    Reportes
                </a>
            </li>
            <li>
                <a id="navbarDropdown" class="actived" href=" <?php echo e(route('cupon.view.edit')); ?>">
                    Editar cupones
                </a>
            </li>
            <li>
                <a id="navbarDropdown"  href=" <?php echo e(route('create.user')); ?>">
                    Crear usuario   
                </a>
            </li>
            <li>
                <a id="navbarDropdown" href=" <?php echo e(route('reset.password')); ?>">
                    Resetear contraseña   
                </a>
            </li>
            <li>
                <a id="navbarDropdown"  href=" <?php echo e(route('change.password')); ?>">
                    Cambiar contraseña
                </a>
            </li>

            <?php endif; ?>
            <?php if(@Auth::user()->hasRole('rol2')): ?>
            <a id="navbarDropdown" class="" href="<?php echo e(route('reportes')); ?>">
                Reportes
            </a>
            <?php endif; ?>

        <li class="nav-item dropdown">
            <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
                Cerrar sesión
            </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
        </li>
    </ul>
</nav>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>  
<div class="div-info">
    <h4 class="user">
        <?php echo e(Auth::user()->name); ?>

    </h4>
    <h4>
    Editar cupones <br>
    </h4>  
</div>
<form method="POST" action="<?php echo e(route('show.edit.admin')); ?>" class="form">
    <?php echo csrf_field(); ?>
    <div class="row mb-3">

            <div class="">
                <input id="placa" type="text" class="input-placa" name="placa" value="<?php echo e($cupon->placa ?? old('placa')); ?>" placeholder="Escrica la placa del vehículo" required>
            </div>
    </div>
    <?php if(Session::has('errorPlaca')): ?>
        <h5 class="text-center">
            <?php echo e(Session::get('errorPlaca')); ?>

        </h5>
    <?php endif; ?>

    <div class="div-button">
        <div class="col-md-6 offset-md-4">
            <button type="submit" class="btn-cupon btn-find">
                Buscar
            </button>
        </div>
    </div>
</form>


<div class="card-body">
    
    <form method="POST" action="<?php echo e(route('cupon.edit.put')); ?>" class="form-update">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        
        <h3 class="card-header">Actualización</h3>
        
        <div class="row mb-3">
            
            <div class="div-placa">
                <label for="placa" class="">Placa: </label>
                <input type="text" class="label-placa" value="<?php echo e($cupon->placa ?? old('placa')); ?>" disabled>
                <input id="placa" type="hidden" class="form-control" name="placa" value="<?php echo e($cupon->placa ?? old('placa')); ?>">
            </div>
        </div>

        <div class="row mb-3">
            <div class="div-estado">
                <label for="placa" class="">Estado: </label>
                <?php if(isset($cupon)): ?>
                    <?php if($cupon->enabled == 1): ?>
                    <select class="form-select" name="value">
                        <option value="1" selected>Sin redimir</option>
                        <option value="0">Redimido</option>
                    </select>
                    <?php else: ?>
                    <select class="form-select" name="value">
                        <option value="1">Sin redimir</option>
                        <option value="0" selected>Redimido</option>
                    </select>
                    <?php endif; ?>
                <?php endif; ?>
                <br>
                <?php if(Session::has('times_updated')): ?>
                    <label>Este cupón ha sido actualizado <?php echo e(Session::get('times_updated')); ?> veces</label>
                <?php endif; ?>
            </div>
            <hr>
        </div>
        <div class="row mb-0 mt-2">
            <div class="col-md-6 offset-md-4">
                <button type="submit" class="btn-cupon btn-update">
                    Actualizar
                </button>
            </div>
        </div>
    </form>
    <div class="div-message">
        <?php if(Session::has('successEdit')): ?>
        <div class="alert alert-success mt-2"><?php echo e(Session::get('successEdit')); ?></div>
        <?php endif; ?>
        
        <?php if(Session::has('errorEdit')): ?>
        <div class="alert alert-warning mt-2"><?php echo e(Session::get('errorEdit')); ?></div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Juan\Downloads\toyota-app\resources\views/cupon-admin.blade.php ENDPATH**/ ?>