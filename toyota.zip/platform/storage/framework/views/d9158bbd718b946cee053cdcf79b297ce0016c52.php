<?php $__env->startSection('header'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<a href="https://www.bpogs.com/toyotaqr/public/">
    <img src="<?php echo e(asset('img/logo-toyota.png')); ?>" alt="LOGO TOYOTA" class="Logo-Toyota">
</a>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">  
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="row mb-3">

                            <div class="col-md-6">
                                <input id="email" type="text" class="input-login" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Usuario">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <input id="password" placeholder="Contraseña" type="password" class="input-login <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                            </div>
                        </div>


                        <div class="row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="button-login">
                                    Inciar sesión
                                </button>
                            </div>
                        </div>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-login" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <footer>
        <div class="text-footer">
            Desarrollado por <a class="a-footer" href="https://www.bpogs.com/" target="_blank">BPO Global Services</a> | Creando Lazos
        </div>
    </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jmorales\Desktop\TOYOTA-APP\toyota-app\resources\views/auth/login.blade.php ENDPATH**/ ?>