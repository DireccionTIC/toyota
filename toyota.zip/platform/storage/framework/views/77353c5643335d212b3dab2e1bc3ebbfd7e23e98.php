

<?php $__env->startSection('content'); ?>
    <h4>Cupones redimidos:</h4>

    <?php if(count($cuponsRedimidos) == 0): ?>
        No hay cupones redimidos<br><br>
    <?php endif; ?>

    <?php $__currentLoopData = $cuponsRedimidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-light border mt-3" role="alert">
            <h4 class="alert-heading"><?php echo e($cupon->placa); ?></h4>
            <hr>
            <p class="mb-0"> <span class="fw-bold">Sitio:</span> <?php echo e($cupon->city); ?><br>
            <span class="fw-bold">Por:</span> <?php echo e($cupon->who); ?><br>
            <span class="fw-bold">Día y hora:</span> <?php echo e($cupon->updated_at); ?><br><br></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jmorales\Desktop\npm\mi-proyecto-laravel\resources\views/reportes-aux.blade.php ENDPATH**/ ?>