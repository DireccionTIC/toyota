
<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/reportes.css')); ?>">
<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
    <a href="/toyotaqr/public" target="__blank">
        <img src="<?php echo e(asset('img/logo-toyota.png')); ?>" alt="LOGO TOYOTA" class="Logo-Toyota">
    </a>
        <!-- Right Side Of Navbar -->
    <ul class="">
        <!-- Authentication Links -->
        <li class="">
            <a id="navbarDropdown" class="" href="<?php echo e(route('home')); ?>">
                Lector
            </a>
        </li>
        <?php if(@Auth::user()->hasRole('admin')): ?>
            <li class="">
                <a id="navbarDropdown"  href=" <?php echo e(route('reportes')); ?> ">
                    Reportes
                </a>
            </li>
            <li>
                <a id="navbarDropdown" class="" href=" <?php echo e(route('cupon.view.edit')); ?>">
                    Editar cupones
                </a>
            </li>
            <li>
                <a id="navbarDropdown"  href=" <?php echo e(route('create.user')); ?>">
                    Crear usuario   
                </a>
            </li>
            <li>
                <a id="navbarDropdown"  class="actived" href=" <?php echo e(route('reset.password')); ?>">
                    Resetear contraseña   
                </a>
            </li>
            <?php endif; ?>
            <?php if(@Auth::user()->hasRole('rol2')): ?>
            <a id="navbarDropdown" class="" href="<?php echo e(route('reportes')); ?>">
                Reportes
            </a>
            <?php endif; ?>
            <li>
                <a id="navbarDropdown"  href=" <?php echo e(route('change.password')); ?>">
                    Cambiar contraseña
                </a>
            </li>
        <li class="nav-item dropdown">
            <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
                Cerrar sesión
            </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
        </li>
    </ul>
</nav>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="body-report">
    <div class="div-title">
        <h1 class="user"><?php echo e(Auth::user()->name); ?></h1>
    </div>
        <form action="<?php echo e(route('resetear.contraseña')); ?>" method="post" class="form">
            <?php echo csrf_field(); ?>
            <select class="form-select" aria-label=".form-select-lg example"  name="concesionario" required>
            <option value="">
                Seleccione una opción
            </option>
                <?php $__currentLoopData = $concesionarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $concesionario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($concesionario); ?>">
                            <?php echo e($concesionario); ?>

                        </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>
            <button type="submit" class="btn-report">Resetear contraseña</button>
            <br>
        </form>
        <?php if(Session::has('success')): ?>
            <strong><?php echo e(Session::get('success')); ?></strong>
        <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jmorales\Desktop\TOYOTA-APP\toyota-app\resources\views/reset-password.blade.php ENDPATH**/ ?>